  // Onepage-slider
  $('.img-slider-web').slick({
    slidesToShow: 1,
    dots: false, 
    arrows: true,
    autoplay: false,
    autoplaySpeed: 3000,
    slidesToScroll: 1
  });

  // Towpage-slider
  $('.img-slider-mobile').slick({
    slidesToShow: 3,
    dots: false, 
    arrows: true,
    autoplay: false,
    autoplaySpeed: 3000,
    slidesToScroll: 1
  });