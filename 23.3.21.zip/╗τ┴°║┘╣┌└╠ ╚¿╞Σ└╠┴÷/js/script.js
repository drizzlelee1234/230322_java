window.addEventListener("load", ()=> {
  const grid = new Isotope("section", {
    itemSelector: "article",
    columWidth: "article",
    transitionDuration: "0.3s"
  });
});